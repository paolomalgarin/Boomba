package Algoritmo;

/**
 * <h1 style="color: #25a76f">Casella</h1>
 * Classe che descrive una casella del campo minato
* @see CampoMinato.java
**/
public class Casella {  //casella del campo minato
    //--------------------------------------------- ATTRIBUTI ---------------------------------------------
    private int value;
    private boolean isFlagged;
    
    //--------------------------------------------- METODI ---------------------------------------------
    //costruttore
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">public</span> Casella(<span style="color: #c0f1dc; font-size: 80%">int value</span>)</h1>
     * Costruttore che genera una nuova casella con il valore value
    **/
    public Casella(int value) {
        this.isFlagged = false;
        if (value > -10 && value < 12)
            this.value = value;
        else
            this.value = 0;
    }
    //get
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">boolean</span> isFlagged()</h1>
     * @return
     * Ritorna il valore di isFlagged, true se la casella ha una bandierina
    **/
    public boolean isFlagged(){
        return this.isFlagged;
    }
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">int</span> getValue()</h1>
     * @return
     * Ritorna il valore della casella, ritorna 11 se la casella ha una bandierina
    **/
    public int getValue() {
        if (!isFlagged)
            return value;
        else
            return 11;
    }
    //set
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">boolean</span> flag()</h1>
     * Posiziona/toglie una flag sulla casella
     * @return
     * Ritorna true se la flag può essere posizionata ed è stata posizionata/tolta
    **/
    public boolean flag(){
        if (value <= 0){
            //flaggo la casella e ritorno se la flag può essere posizionata
            this.isFlagged = !this.isFlagged;
            return true;
        }
        else
            return false;
    }
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">void</span> setValue(<span style="color: #c0f1dc; font-size: 80%">int value</span>)</h1>
     * Setta il valore della casella
    **/
    public void setValue(int value) {
        this.value = value;
    }
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">void</span> decrementa()</h1>
     * Decrementa il valore della casella
    **/
    public void decrementa(){
        this.value--;
    }
    //toString
    @Override
    public String toString() {
        return ((this.isFlagged)? 11 : value) + "";
    }
}
