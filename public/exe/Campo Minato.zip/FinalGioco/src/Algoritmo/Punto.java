package Algoritmo;

/**
 * <h1 style="color: #25a76f">Punto</h1>
 * Classe che descrive un punto all'interno di una matrice
* @see CampoMinato.java
**/
public class Punto {
    //--------------------------------------------- ATTRIBUTI ---------------------------------------------
    public int x;
    public int y;
    
    //--------------------------------------------- METODI ---------------------------------------------
    //cotruttori
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">public</span> Punto()</h1>
     * Costruttore che genera un nuovo punto in (0, 0)
    **/
    public Punto() {
        this.x = 0;
        this.y = 0;
    }
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">public</span> Punto(<span style="color: #c0f1dc; font-size: 80%">int x, int y</span>)</h1>
     * Costruttore che genera un nuovo punto in (x, y)
    **/
    public Punto(int x, int y) {
        this.x = x;
        this.y = y;
    }
    //equals
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">boolean</span> Punto(<span style="color: #c0f1dc; font-size: 80%">Punto p</span>)</h1>
     * Ritorna true se i punti sono congruenti<br>
     * (stessa x e stessa y)
    **/
    public boolean equals(Punto p) {
        return this.x == p.x && this.y == p.y;
    }
}
