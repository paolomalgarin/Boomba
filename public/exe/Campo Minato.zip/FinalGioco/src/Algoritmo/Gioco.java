package Algoritmo;


public class Gioco {

    public static void main(String[] args) {
        CampoMinato c = new CampoMinato(Difficulty.easy);
        
        //stampa iniziale
        System.out.print(c);
        
        System.out.println("");
//        c.click(new Punto(4,4));
        System.out.print(c);
        
        c.placeFlag(new Punto(3, 3));
        c.placeFlag(new Punto(8, 8));
        c.placeFlag(new Punto(7, 8));
        c.placeFlag(new Punto(6, 8));
        c.placeFlag(new Punto(5, 8));
        c.placeFlag(new Punto(4, 8));
        c.placeFlag(new Punto(3, 8));
        c.placeFlag(new Punto(2, 8));
        c.placeFlag(new Punto(1, 8));
        c.placeFlag(new Punto(0, 8));
        c.placeFlag(new Punto(0, 0)); //non va in diff easy
        System.out.println("");
        System.out.print(c);
    }
    
}
