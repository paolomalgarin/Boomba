package Algoritmo;

import java.util.Random;

/**
 * <h1 style="color: #25a76f">Mina</h1>
 * Classe che descrive una mina all'interno di un oggetto CampoMinato
* @see CampoMinato.java
**/
class Mina {
    /*
            !!! X MAX GENERALE = 30 (bound -> limite = 29)
            !!! Y MAX GENERALE = 16 (bound -> limite = 15)
    */
    //--------------------------------------------- ATTRIBUTI ---------------------------------------------
    private static Random r = new Random();
    private int xBound;  //limite dell'asse delle x (è uguale alla x in -> new int[x][y])
    private int yBound;  //limite dell'asse delle y (è uguale alla y in -> new int[x][y])
    private Punto pos;
    
    //--------------------------------------------- METODI ---------------------------------------------
    //costruttori
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">public</span> Mina(<span style="color: #c0f1dc; font-size: 80%">int xBound, int yBound</span>)</h1>
     * Costruttore che genera una nuova mina all'interno della matrice
     * @param xBound è il numero delle righe
     * @param yBound è il numero delle colonne
    **/
    public Mina(int xBound, int yBound){
        //controllo che i bounds rispettino i limiti massimi
        if(xBound < 31)
            this.xBound = xBound;
        else
            this.xBound = 30;
        if(yBound < 17)
            this.yBound = yBound;
        else
            this.yBound = 16;
        //faccio il resto
        this.pos = new Punto(r.nextInt(xBound), r.nextInt(yBound));
    }
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">public</span> Mina(<span style="color: #c0f1dc; font-size: 80%">int x, int y, int xBound, int yBound</span>)</h1>
     * Costruttore che genera una nuova mina all'interno della matrice
     * @param xBound è il numero delle righe
     * @param yBound è il numero delle colonne
     * @param x è la x del punto in cui viene messa la mina
     * @param y è la y del punto in cui viene messa la mina
    **/
    public Mina(int x, int y, int xBound, int yBound){
        this(xBound, yBound);
        if (x < xBound)
            this.pos.x = x;
        if (y < yBound)
            this.pos.y = y;
    }
    //get
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">Punto</span> getCoord()</h1>
     * @return
     * Ritorna la posizione della mina
     * @see Punto.java
    **/
    public Punto getCoord(){
        return pos;
    }
    //set
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">boolean</span> setCoord(<span style="color: #c0f1dc; font-size: 80%">int x, int y</span>)</h1>
     * @return
     * Ritorna true se le coordinate sono valide (sono all'interno della matrice)
    **/
    public boolean setCoord(int x, int y){
        //caso in cui il punto sia fuori dalla matrice
        if (x >= xBound || y >= yBound)
            return false;
        
        //caso regolare
        this.pos.x = x;
        this.pos.y = y;
        return true;
    }
}
