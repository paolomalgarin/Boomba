package Algoritmo;

/**
 *
 * @author paolo
 */
public class AutoWin extends Thread {
    CampoMinato c;
    
    public AutoWin(CampoMinato c) {
        this.c = c;
    }

    @Override
    public void run() {
        System.out.println("AUTOWIN ACTIVATED!\n");
        for (int i = 0; i < c.getBounds().x; i++)
            for (int j = 0; j < c.getBounds().y; j++)
                if(c.getAt(new Punto(i, j)) <=0 && c.getAt(new Punto(i, j)) != -9) {
                    c.click(new Punto(i, j));
                    System.out.println(c);
                }
    }
    
    
}
