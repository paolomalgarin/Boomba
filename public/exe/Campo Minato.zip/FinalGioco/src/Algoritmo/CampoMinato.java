package Algoritmo;

import java.io.File;
import javax.sound.sampled.*;
import java.util.ArrayList;
import java.util.Random;

/**
 * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">class</span> CampoMinato</h1>
 * <h2 style="text-align: center;"> SIGNIFICATO NUMERI IN MATRICE (campo)</h2>
 * <ul style="list-style-type: none;">
    <li> -9 -> mina *coperto*
    <li> -8 -> 8 mine. nei blocchi adiacenti *coperto*
    <li> ...
    <li> -1 -> 1 mina nei blocchi adiacenti *coperto*
    <li> 0 -> spazio vuoto coperto (numeri minori di 1 sono tutti coperti)
    <li> 1 -> 1 mina nei blocchi adiacenti
    <li> 2 -> 2 mine nei blocchi adiacenti
    <li> ...
    <li> 8 -> 8 mine nei blocchi adiacenti
    <li> 9 -> mina scoperta (per visualizzare le mine a fine partita)
    <li> 10 -> spazio vuoto (scoperto)
    <li> 11 -> segnalino
 * </ul>

    * @see Mina.java
    * @see Difficulty.java
    * @see Punto.java
    * @see Casella.java
 */
public class CampoMinato {
    //--------------------------------------------- ATTRIBUTI ---------------------------------------------
    private Casella[][] campo;   //matrice del campo
    private Punto bounds;  //limiti della matrice
    private ArrayList <Mina> mine;  //mine del campo
    private boolean isFirstClick;  //flag per il primo click
    private Difficulty diff;  //difficoltà di gioco
    private int maxFlags;  //massimo numero di flags posizionabili
    private int flags;  //numero di flags posizionate
    
    //--------------------------------------------- METODI ---------------------------------------------
    //costruttori
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">public</span> CampoMinato(<span style="color: #c0f1dc; font-size: 80%">Difficulty diff</span>)</h1>
     * Costruttore che genera un nuovo campo minato randomicamente
    **/
    public CampoMinato(Difficulty diff) {
        this.isFirstClick = true;
        this.diff = diff;
        this.flags = 0;
        //setup bounds
        switch(diff){
            case easy:
                bounds = new Punto(9, 9);
            break;
            case medium:
                bounds = new Punto(16, 16);
            break;
            case hard:
                bounds = new Punto(30, 16);
            break;
        }
        //creazione campo
        this.campo = new Casella[bounds.x][bounds.y];
        this.generaCampo();
    }
    //generazione
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">void</span> generaMine()</h1>
     * Genera casualmente delle mine in base alla difficoltà, ma non le mette nella matrice.<br>
     * Imposta anche il numero di flags massimo
    **/
    private void generaMine(){
        int nMine = 0;
        mine = new ArrayList();
        //check della difficoltà
        switch(diff){
            case easy:
                nMine = 10;
            break;
            case medium:
                nMine = 40;
            break;
            case hard:
                nMine = 99;
            break;
        }
        this.maxFlags = nMine;
        while(mine.size() < nMine){
            Mina tmp = new Mina(bounds.x, bounds.y);
            if (! this.isPresente(tmp.getCoord()))
                mine.add(tmp);
        }
    }
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">void</span> generaBordi(<span style="color: #c0f1dc; font-size: 80%">Punto p</span>)</h1>
     * <p> Genera i numeretti in torno alle mine, nella matrice.</p>
     * <p style="color: #d64343;"><strong>Genera un errore</strong>:<br>Le mine anzichè avere il valore a loro assegnato (-9) potrebbero averne altri minori di quello.</p>
    **/
    public void generaBordi(Punto p){  //genera i bordi in torno alle mine
        for (int i = -1; i < 2; i++)
            for (int j = -1; j < 2; j++)
                if(i != 0 || j !=0)
                    try{
                        campo[p.x+i][p.y-j].decrementa();  //decremento del valore
                    } catch (Exception e) {}
    }
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">void</span> generaCampo()</h1>
     * <p>Inizializza la matrice, genera i bounds in base alla difficoltà, chiama generaMine(), posiziona le mine,
     * crea i bordi in torno con generaBordi() e sistema gli errori del metodo generaBordi().</p>
    **/
    public void generaCampo(){
        //setup generale del campo
        for (int i = 0; i < bounds.x; i++) {
            for (int j = 0; j < bounds.y; j++) {
                campo[i][j] = new Casella(0);
            }
        }
        
        //setup mine
        switch(diff){
            case easy:
                bounds = new Punto(9, 9);
            break;
            case medium:
                bounds = new Punto(16, 16);
            break;
            case hard:
                bounds = new Punto(30, 16);
            break;
        }
        generaMine();
        for (Mina mina : mine)
            //sistemo la roba in torno
            this.generaBordi(mina.getCoord());
        //sistemo le aggiunte extra sulle mine (errori di generaMine())
        for (Mina mina : mine)
            //metto le mine
            campo[mina.getCoord().x][mina.getCoord().y].setValue(-9);
    }
    //get & set
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">int</span> getAt(<span style="color: #c0f1dc; font-size: 80%">Punto p</span>)</h1>
     * @param p
     * è il punto che indica la casella della matrice
     * @return Ritorna il valore presente alla casella specificata o -100 in caso di errore
    **/
    public int getAt(Punto p){
        if (ceckBounds(p))
            return campo[p.x][p.y].getValue();
        else
            return -100;
    }
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">int</span> setAt(<span style="color: #c0f1dc; font-size: 80%">Punto p, int value</span>)</h1>
     * @param p
     * è il punto che indica la casella della matrice
     * @param value
     * è il valore che otterrà la casella della matrice
    **/
    public void setAt(Punto p, int value){
        if (ceckBounds(p))
            campo[p.x][p.y].setValue(value);
    }
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">Punto</span> getBounds()</h1>
     * @return Ritorna i limiti della matrice
    **/
    public Punto getBounds(){
        return this.bounds;
    }
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">int</span> getFlags()</h1>
     * @return Ritorna il numero di flags posizionate in un determinato momento
    **/
    public int getFlags(){
        return this.flags;
    }
    //checks
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">boolean</span> isPresente(<span style="color: #c0f1dc; font-size: 80%">Punto p</span>)</h1>
     * @param p
     * è il punto che indica la casella della matrice
     * @return Ritorna true se in quella casella è presente una mina
    **/
    public boolean isPresente(Punto p){  //controlla se la mina esiste già in quel punto
        for (Mina mina : mine) {
            if (mina.getCoord().equals(p))
                return true;
        }
        return false;
    }
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">boolean</span> ceckBoundss(<span style="color: #c0f1dc; font-size: 80%">Punto p</span>)</h1>
     * @param p
     * è il punto che indica la casella della matrice
     * @return Ritorna true se il punto è dentro la matrice
    **/
    public boolean ceckBounds(Punto p){  //controlla se il punto rispetta i limiti
        if (p.x < bounds.x && p.y < bounds.y)
            return true;
        return false;
    }
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">boolean</span> isVinta()</h1>
     * @return Ritorna true se la partita è stata vinta (tutte le caselle senza mina sono state scoperte)
    **/
    public boolean isVinta(){
        for (int i = 0; i < bounds.x; i++)
            for (int j = 0; j < bounds.y; j++)
                if(campo[i][j].getValue() <= 0 && campo[i][j].getValue() != -9)
                    return false;
        return true;
    }
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">boolean</span> isMaxFlags()</h1>
     * @return Ritorna true se abbiamo raggiunto o superato il numero max di flags posizionabili
    **/
    public boolean isMaxFlags(){
        return !(this.flags < this.maxFlags);
    }
    //azioni
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">int</span> placeFlag(<span style="color: #c0f1dc; font-size: 80%">Punto p</span>)</h1>
     * Metodo che posiziona una flag in un punto, alzando la flag all'elemento Casella
     * presente in quel punto e rendendo il suo valore pari a 11;
     * Il metodo controlla in automatico i bounds.
     * 
     * @param p
     * è il punto in cui posizionare la flag
     * @return 
     * Ritorna un boolean:<br>
     *   -> true = flag posizionata con successo<br>
     *   -> false = errore: la flag non può essere posizionata in quel punto
    **/
    public boolean placeFlag(Punto p){  // true = posizionata con successo, false = errore
        if (ceckBounds(p)){
            //se la flag è in un punto nella matrice e coperto, cambio il numero di flags
            if (campo[p.x][p.y].isFlagged()) {
                campo[p.x][p.y].flag();
                flags--;
            } else
                if(!this.isMaxFlags()){
                    campo[p.x][p.y].flag();
                    flags++;
                } else 
                    return false;
            return true;
        }
        return false;
    }
    /**
     * <h1 style="color: #25a76f"><span style="color: #c0f1dc; font-size: 80%">boolean</span> click(<span style="color: #c0f1dc; font-size: 80%">Punto p</span>)</h1>
     * Metodo che scopre la casella al unto p e modifica la matrice di
     * conseguenza.
     *
     * @param p è il punto selezionato dall'utente
     * @return
     * Ritorna un int:<br>
     *   -> -1 = il punto selezionato è una mina: hai perso<br>
     *   ->  0 = casella scoperta con successo (non c'era una mina)<br>
     *   ->  1 = scoprendo quella casella hai vinto il gioco!
     */
    public int click(Punto p){
        if((campo[p.x][p.y].getValue() == 9 || campo[p.x][p.y].getValue() == -9) && !isFirstClick) {
            //sound
            File file = new File("src/audio/boom.wav");
            try {
                AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(file);
                Clip clip = AudioSystem.getClip();
                clip.open(audioInputStream);
                clip.start();
            } catch (Exception e) { System.out.println("Error playing sound: " + e.getMessage()); }
            return -1;
        }
        
        if(!campo[p.x][p.y].isFlagged() && getAt(p) <= 0)
            scopriCasella(p);
            
        //ritorno se ha perso o no
        if (isVinta())
            return 1;
        return 0;
    }
    private void scopriCasella(Punto p){
        //caso in cui il punto sia fuori dal campo o non sia vuoto
        if (p.x >= bounds.x || p.y >= bounds.y)
            return;
        
        //caso primo click
        if (isFirstClick) {
            while(campo[p.x][p.y].getValue() != 0) {
                this.generaCampo();
            }
            this.flags = 0;
            this.isFirstClick = false;
        }
        
        //caso generale
        ScopriCasellaThr tmp = new ScopriCasellaThr(this, p);
        tmp.run();
        try {
            tmp.join();
        } catch (InterruptedException ex) {
        }
        //sound
        File file = new File("src/audio/grass-" + (new Random().nextInt(6) + 1) + ".wav");
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(file);
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        } catch (Exception e) {
            System.out.println("Error playing sound: " + e.getMessage());
        }
    }
    //Overrides
    /**
     *  *SOLO PER TEST*
    **/
    @Override
    public String toString() {  //metodo per test
        String out = "";
        for (int i = 0; i < bounds.y; i++) {
            for (int j = 0; j < bounds.x; j++) {
                Punto p = new Punto(j, i);
                if (String.valueOf(campo[j][i]).length() == 1){
                    if (getAt(p) == 9)
                        out += "\u001B[41m";
                    else if (getAt(p) > 0)
                        out += "\u001B[36m";
                    out += "0" + campo[j][i].toString();
                    out += "\u001B[40m\u001B[0m ";
                } else {
                    if (getAt(p) == -9)
                        out += "\u001B[41m";
                    else if (getAt(p) == 11)
                        out += "\u001B[46m";
                    else if (getAt(p) > 0)
                        out += "\u001B[36m";
                    out += campo[j][i].toString() + "\u001B[40m\u001B[0m ";
                }
            }
            out += "\n";
        }
        return out;
    }
}
