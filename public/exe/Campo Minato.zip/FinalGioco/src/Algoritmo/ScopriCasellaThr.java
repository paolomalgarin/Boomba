package Algoritmo;

import java.util.ArrayList;

class ScopriCasellaThr extends Thread {

    private static CampoMinato campo;
    private Punto p;

    public ScopriCasellaThr(CampoMinato campo, Punto p) {
        super();
        this.p = p;
        this.campo = campo;
    }

    public ScopriCasellaThr(Punto p) {
        super();
        this.p = p;
    }

    @Override
    public void run() {
        ArrayList<ScopriCasellaThr> childrens = new ArrayList();
        
        //caso in cui il punto sia fuori dal campo o non sia vuoto
        if (p.x >= campo.getBounds().x || p.y >= campo.getBounds().y)
            return;

        if (campo.getAt(p) <= 0) {
            if (campo.getAt(p) < 0) {
                //converto nella versione visibbile dell'elemento
                campo.setAt(p, (int) Math.sqrt(campo.getAt(p) * campo.getAt(p)));
//                System.out.println("Scoperta -> (" + p.x + ", " + p.y + ")");
                
            } else {
                //caso casella vuota
                campo.setAt(p, 10);
//                System.out.println("Scoperta -> (" + p.x + ", " + p.y + ")");

                for (int i = -1; i < 2; i++) {
                    for (int j = -1; j < 2; j++)
                        try {
                        if (campo.getAt(new Punto(p.x + i, p.y + j)) <= 0 && (i != 0 || j != 0)) {
                            ScopriCasellaThr tmp = new ScopriCasellaThr(new Punto(p.x + i, p.y + j));
                            childrens.add(tmp);
                            tmp.start();
                        }
                    } catch (Exception e) {
                    }
                }
            }
        }

        //aspetto che tutti finiscano per evitare errori di rendering
        for (ScopriCasellaThr children : childrens) {
            try {
                children.join();
            } catch (InterruptedException ex) {
            }
        }
    }

}
