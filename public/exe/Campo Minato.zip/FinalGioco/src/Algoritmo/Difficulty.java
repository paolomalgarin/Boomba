package Algoritmo;

/**
 * <h1 style="color: #25a76f">Difficulty</h1>
 * Descrive la difficoltà della partita, in base alla quale l'oggetto<br>
 * CampoMinato modificherà la grandezza della matrice e il numero di mine
 *
 * @see Mina.java
 * @see CampoMinato.java
 */
public enum Difficulty {
    /**
     * <h1 style="color: #25a76f">Difficulty
     * <span style="color: #c0f1dc; font-size: 80%">easy</span></h1>
     * Campo 9 × 9 con 10 mine
     */
    easy, //Principiante: campo 9 × 9 con 10 mine
    /**
     * <h1 style="color: #25a76f">Difficulty
     * <span style="color: #c0f1dc; font-size: 80%">medium</span></h1>
     * Campo 16 × 16 con 40 mine
     */
    medium, //Intermedio: campo 16 × 16 con 40 mine
    /**
     * <h1 style="color: #25a76f">Difficulty
     * <span style="color: #c0f1dc; font-size: 80%">hard</span></h1>
     * Campo 30 × 16 con 99 mine
     */
    hard  //Esperto: campo 30 × 16 con 99 mine.
}
