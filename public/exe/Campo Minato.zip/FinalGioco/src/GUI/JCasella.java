package GUI;

import java.awt.Color;
import javax.swing.JLabel;

public class JCasella extends JLabel {

    //mi serve per creare un oggetto con la Jlabel e la posizione di essa
    public final int X, Y;

    public JCasella(int x, int y) {
        super();
        this.X = x;
        this.Y = y;
        this.ChangeImage(Stato.COPERTA);
    }

    public void ChangeImage(Stato s) {

        switch (s) {
            default:
            case COPERTA:
                this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/coperta.jpg")));
                break;
            case BRUCIATA:
                this.setIcon(new javax.swing.ImageIcon());
                this.setBackground(new Color(0, 0, 0));               
                break;
            case SCOPERTA:
                this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/scoperta.jpg")));
                break;

            case FLAG:
                this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/flag.png")));
                break;
            case MINA:
                this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bomba.png")));
                break;
            case ESPLOSIONE:
                this.setIcon(new javax.swing.ImageIcon());
                this.setBackground(new Color(255, 0, 0));
                break;
            case NUM_1:
                this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/1.png")));
                break;
            case NUM_2:
                this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/2.png")));
                break;
            case NUM_3:
                this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/3.png")));
                break;
            case NUM_4:
                this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/4.png")));
                break;
            case NUM_5:
                this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/5.png")));
                break;
            case NUM_6:
                this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/6.png")));
                break;
            case NUM_7:
                this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/7.png")));
                break;
            case NUM_8:
                this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/8.png")));
                break;          
        }
    }
    

}
