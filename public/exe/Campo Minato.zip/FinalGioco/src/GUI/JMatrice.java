package GUI;

import Algoritmo.*;
import java.awt.Image;
import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;

public class JMatrice {

    CampoMinato c;
    JCasella[][] labels;
    long startTime = 0;
    boolean flagms = true;
    private Flag flag;

    public JMatrice(JCampoMinato frame, Flag flag, Difficulty diff, String name, Classifica classifica) {

        c = new CampoMinato(diff);
        labels = new JCasella[c.getBounds().x][c.getBounds().y];
        this.flag = flag;

        System.out.println(c);
//        for (int i = 0; i < c.getBounds().x; i++) {
//            for (int j = 0; j < c.getBounds().y; j++) {
//                System.out.println("Valore restituito da c.getAt(new Punto(" + i + ", " + j + ")): " + c.getAt(new Punto(i, j)));
//            }
//        }

        // Carica l'immagine
        for (int i = 0; i < c.getBounds().x; i++) {
            for (int j = 0; j < c.getBounds().y; j++) {
                labels[i][j] = new JCasella(i, j);
                labels[i][j].setBounds(41 * i + 2, 41 * j + 2, 40, 40);

                // Aggiungi un listener per i clic su ciascun JLabel
                labels[i][j].addMouseListener(new MouseAdapter() {
                    @Override
                    public void mousePressed(MouseEvent e) {
                        JCasella clickedLabel = (JCasella) e.getSource();
                        
                        // ---------------- AUTOWIN X TEST ----------------
//                        if (SwingUtilities.isMiddleMouseButton(e)) {
//                            AutoWin win = new AutoWin(c);
//                            win.start();
//                            try { win.join(); } catch (InterruptedException ex) {}
//                            RefreshStatoJCasella();
//                        }
                        // ---------------- AUTOWIN X TEST ----------------

                        if (SwingUtilities.isLeftMouseButton(e)) {
                            System.out.println("Tasto sinistro - Coordinate (X, Y): (" + clickedLabel.X + ", " + clickedLabel.Y + ")");
                            if (c.click(new Punto(clickedLabel.X, clickedLabel.Y)) == -1) {  //caso sconfitta
                                flag.setPersa();
                                RefreshStatoJCasella();
                                RevealSlowBombe(frame, diff);
                                removeMouseListeners();
                                cambiaSfondoConImmagine(frame, "img/GameOver.jpg");
                            } else if (c.click(new Punto(clickedLabel.X, clickedLabel.Y)) == 1) {  //caso vittoria
                                new Thread(() -> {
                                    try {
                                        Thread.sleep(700);
                                    } catch (InterruptedException ex) {
                                        ex.printStackTrace();
                                    }
                                    long stopTime = System.currentTimeMillis();
                                    long elapsedTime = (stopTime - startTime) / 1000;
                                    System.out.println("tempo: " + elapsedTime);
                                    JOptionPane.showMessageDialog(null, "tempo: " + (elapsedTime/60 < 10 ? "0" : "") + elapsedTime/60 + ":" + (elapsedTime%60 < 10 ? "0" : "") + elapsedTime%60 + " min");

                                    flag.setVinta();
                                    removeMouseListeners();
                                    Exsplosion(frame, diff);
                                    cambiaSfondoConImmagine(frame, "img/win.jpg");

                                    try {
                                        classifica.calcolaPunteggio(elapsedTime, c.getBounds().x * c.getBounds().y);
                                        classifica.ScriviDati(classifica.getStats());
                                    } catch (IOException ex) {
                                    }
                                }).start();
                            } else {  //caso generale
                                if (flagms) {
                                    startTime = System.currentTimeMillis();
                                    flagms = false;
                                }
                                RefreshStatoJCasella();
                            }

                        } else {  //tasto destro
                            System.out.println("Tasto destro - Coordinate (X, Y): (" + clickedLabel.X + ", " + clickedLabel.Y + ")");
                            c.placeFlag(new Punto(clickedLabel.X, clickedLabel.Y));

                            if (c.getAt(new Punto(clickedLabel.X, clickedLabel.Y)) == 11) {
                                flag.addFlag();
                            } else if (c.getAt(new Punto(clickedLabel.X, clickedLabel.Y)) <= 0 && !c.isMaxFlags()) {
                                flag.removeFlag();
                            }
                            System.out.println("Il numero delle flag utilizzate è : " + flag.getFlagCount());
                            RefreshStatoJCasella();
                        }

                        System.out.println(c);  //stampa stato campo
                    }

                });

                frame.getContentPane().add(labels[i][j]);

            }
        }
        RefreshStatoJCasella();

    }

    public void RefreshStatoJCasella() {
        if (c.getFlags() == 0) {
            flag.resetAllFlag();
        }

        for (int i = 0; i < c.getBounds().x; i++) {
            for (int j = 0; j < c.getBounds().y; j++) {
                if (c.getAt(new Punto(i, j)) <= 0) {
                    labels[i][j].ChangeImage(Stato.COPERTA);
                } else {
                    switch (c.getAt(new Punto(i, j))) {
                        case 1:
                            labels[i][j].ChangeImage(Stato.NUM_1);
                            break;
                        case 2:
                            labels[i][j].ChangeImage(Stato.NUM_2);
                            break;
                        case 3:
                            labels[i][j].ChangeImage(Stato.NUM_3);
                            break;
                        case 4:
                            labels[i][j].ChangeImage(Stato.NUM_4);
                            break;
                        case 5:
                            labels[i][j].ChangeImage(Stato.NUM_5);
                            break;
                        case 6:
                            labels[i][j].ChangeImage(Stato.NUM_6);
                            break;
                        case 7:
                            labels[i][j].ChangeImage(Stato.NUM_7);
                            break;
                        case 8:
                            labels[i][j].ChangeImage(Stato.NUM_8);
                            break;
                        case 9:
                            labels[i][j].ChangeImage(Stato.MINA);
                            break;
                        case 10:
                            labels[i][j].ChangeImage(Stato.SCOPERTA);
                            break;
                        case 11:
                            labels[i][j].ChangeImage(Stato.FLAG);
                            break;
                    }
                }
            }
        }
    }

    public void removeMouseListeners() {    //rimuove
        for (int i = 0; i < c.getBounds().x; i++) {
            for (int j = 0; j < c.getBounds().y; j++) {
                MouseListener[] mouseAdapters = labels[i][j].getMouseListeners();   //creo un array di MouseListener e gli rimuovo alle Label
                for (MouseListener mouseAdapter : mouseAdapters) {
                    labels[i][j].removeMouseListener(mouseAdapter);
                }
            }
        }
    }

    public void RevealSlowBombe(JFrame frame, Difficulty diff) {
        new Thread(() -> {
            for (int i = 0; i < c.getBounds().x; i++) {
                for (int j = 0; j < c.getBounds().y; j++) {
                    if (c.getAt(new Punto(i, j)) == -9) {
                        labels[i][j].ChangeImage(Stato.MINA);
                        if (diff != Difficulty.easy) {
                            try {
                                Thread.sleep(15);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        } else {
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
            // Dopo aver rivelato le bombe, avvia l'esplosione
            Exsplosion(frame, diff);
        }).start();
    }

    public void Exsplosion(JFrame frame, Difficulty diff) {
        new Thread(() -> {
            for (int i = 0; i < c.getBounds().x; i++) {
                for (int j = 0; j < c.getBounds().y; j++) {
                    labels[i][j].ChangeImage(Stato.ESPLOSIONE);
                    if (diff != Difficulty.easy) {
                        try {
                            Thread.sleep(10);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        try {
                            Thread.sleep(50);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    labels[i][j].ChangeImage(Stato.BRUCIATA);
                }
            }
            RemoveLabel(frame);
        }).start();
    }

    public void cambiaSfondoConImmagine(JFrame frame, String percorso) { //crea una label lunga tutto il frame, gli assegna l'immagine e lo mostra
        try {
            // Carica l'immagine da file utilizzando ClassLoader
            ImageIcon icon = new ImageIcon(getClass().getClassLoader().getResource(percorso));
            Image img = icon.getImage();

            // Crea un JLabel con l'immagine e impostalo come sfondo
            JLabel sfondo = new JLabel(icon);

            // Imposta le dimensioni del JLabel per adattarlo al JFrame
            sfondo.setBounds(0, 0, frame.getWidth(), frame.getHeight());

            // Imposta il layout del content pane del JFrame come null per sovrapporre il JLabel
            frame.getContentPane().setLayout(null);

            // Aggiungi il JLabel al content pane e spostalo in cima agli altri componenti
            frame.getContentPane().add(sfondo);

            // Assicurati che il JLabel sia visibile
            sfondo.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void RemoveLabel(JFrame frame) {
        new Thread(() -> {
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            for (int i = 0; i < c.getBounds().x; i++) {
                for (int j = 0; j < c.getBounds().y; j++) {
                    labels[i][j].setVisible(false);
                }
            }
        }).start();

    }

}
