package GUI;

import Algoritmo.Difficulty;
import static Algoritmo.Difficulty.easy;
import static Algoritmo.Difficulty.hard;
import static Algoritmo.Difficulty.medium;
import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import javax.swing.JFrame;

// -------------------------> PER ME E' MEGLIO METTERE LA BARRA DIRETTAMENTE SOTTO IL CAMPO <-------------------------
public class Flag extends javax.swing.JFrame {

    // --------------------------------------------------- ATTRIBUTI ---------------------------------------------------
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel[] labels = new javax.swing.JLabel[10];
    private int nflag = 0;
    private int maxFlags;
    private boolean isPersa = false;
    private boolean isVinta = false;
    private Point mouseClickPoint = null;
    private static boolean isFlagAttached;  //attributo condiviso per attaccamento al gioco
    private static JCampoMinato parent;

    // --------------------------------------------------- METODI ---------------------------------------------------
    //costruttore
    public Flag(JCampoMinato parent, Difficulty d, int x, int y, Boolean isFlagAttached) {
        this.parent = parent;
        initComponents(d, x, y, isFlagAttached);
    }
    //initcomponents
    private void initComponents(Difficulty d, int x, int y, Boolean isFlagAttached) {
        // ------------------------ FROM ------------------------ 
        getContentPane().setLayout(null);
        this.setUndecorated(true);
        //set dimensioni
        switch (d) {
            case easy:
                setBounds(0, 0, 41*9 + 4, 60);
                maxFlags = 10;
                break;
            case medium:
                setBounds(0, 0, 41*16 + 19, 60);
                maxFlags = 40;
                break;
            case hard:
                setBounds(0, 0, 41*30 + 19, 60);
                maxFlags = 99;
                break;
        }
        //set posizione
        setPos(x, y);
        System.out.println(x);
        System.out.println(y);
        //altro
        this.isFlagAttached = isFlagAttached;
        setDefaultCloseOperation(Flag.DO_NOTHING_ON_CLOSE);
        this.setVisible(true);
        Color blue = new Color(180, 206, 180);        
        this.getContentPane().setBackground(blue);
        
        this.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2)
                    ((Flag)evt.getSource()).setExtendedState(JFrame.ICONIFIED);
            }
        });
        this.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                mouseClickPoint = e.getPoint();
            }
        });
        this.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                Point currentCoords = e.getLocationOnScreen();
                ((Flag)e.getSource()).setLocation(currentCoords.x - mouseClickPoint.x, currentCoords.y - mouseClickPoint.y);
                    
                if (!Flag.isFlagAttached) {
                    if (getY() <= (parent.getY() + parent.getHeight() + 20) && getY() > (parent.getY() + parent.getHeight() - 20))
                        Flag.isFlagAttached = true;
                } else {
                    if (getY() > (parent.getY() + parent.getHeight() + 20) || getY() <= (parent.getY() + parent.getHeight() - 20)) {
                        Flag.isFlagAttached = false;
                    }
                }
            }
        });

        // ------------------------ COMPONENTI ------------------------ 
        //panel
        jPanel1 = new javax.swing.JPanel();
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51), 5));
        jPanel1.setBounds(5, 5, this.getBounds().width - 10, this.getBounds().height - 10);
        jPanel1.setLayout(null);
        jPanel1.setBackground(new Color(51, 66, 51));
        getContentPane().add(jPanel1);

        //labels
        for (int i = 0; i < 10; i++) {
            //var tmp
            final Rectangle panelBounds = jPanel1.getBounds();
            final int labelHeight = panelBounds.height - 14;  // -14 => { 10 x i bordi (5 e 5) + 4 per il padding }
            final int labelWidth = (panelBounds.width - 14 - 16) / 10;  // -14 è il padding, -18 è la somma totale dei gap delle labels (2px) senza contare il padding che fa gia da gap
            //set labels
            labels[i] = new javax.swing.JLabel();
            labels[i].setBounds(7 + (labelWidth + 2)*i , 7, labelWidth, labelHeight);
            labels[i].setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51), 3));
            labels[i].setOpaque(true);
            labels[i].setBackground(new Color(180, 206, 180));
            jPanel1.add(labels[i]);
        }
        
//        this.setVinta();
//        this.setPersa();
        refresh();
    }
    
    //metodi miei
    private void refresh(){
        try {
            for (int i = 0; i < 10; i++) {
                Color bg, border;
                if( i < nflag*10/maxFlags) {
                    if(isPersa) {  //caso sconfitta
    //                    Thread.sleep(200);  //per timare l'accensione della barra sotto
                        bg = new Color(255, 51, 51);
                        border = new java.awt.Color(51, 0, 0);
                    } else if (isVinta) {  //caso vittoria
    //                    Thread.sleep(200);  //per timare l'accensione della barra sotto
                        bg = new Color(204, 204, 0);
                        border = new java.awt.Color(51, 51, 0);
                    } else {  //caso generale
                        bg = new Color(51, 255, 0);
                        border = new java.awt.Color(0, 51, 0);
                    }
                } else {
                    bg = new Color(180, 206, 180);
                    border = new java.awt.Color(51, 51, 51);
                }
                labels[i].setBackground(bg);
                labels[i].setBorder(javax.swing.BorderFactory.createLineBorder(border, 3));
            }
        } catch (Exception e){}
        if(nflag == maxFlags){
            if(isPersa){
                jPanel1.setBackground(new Color(255, 102, 102));
                
            }
            if (isVinta){
                jPanel1.setBackground(new Color(255, 255, 153));                
            }
        }
    }
    
    //metodi utilizabili
    public void setPersa(){  //setta a persa la partita e mette tutte le flags a rosso
        this.isPersa = true;
        refresh();
    }
    public void setVinta(){  //setta a vinta la partita e mette tutte le flags ad oro
        this.isVinta = true;
        refresh();
    }
    public void addFlag() {
        nflag++;
        refresh();
    }
    public void removeFlag() {
        nflag--;
        refresh();
    }
    public void resetAllFlag() {
        nflag = 0;
        refresh();
    }
    public int getFlagCount() {
        return nflag;
    }
    public void setFlagColor(int index, java.awt.Color bg, java.awt.Color border) {
        labels[index].setBackground(bg);
        labels[index].setBorder(javax.swing.BorderFactory.createLineBorder(border, 3));
    }
    public void setAllFlagColor(java.awt.Color bg, java.awt.Color border) {
        for (int i = 0; i < nflag*10/maxFlags; i++) {
            labels[i].setBackground(bg);
            labels[i].setBorder(javax.swing.BorderFactory.createLineBorder(border, 3));
        }
    }
    public void setPos(int x, int y) {
        this.setLocation(x + 8, y);
    }
    
    public boolean getIsFlagAttached() {
        return this.isFlagAttached;
    }
}
