package GUI;

import Algoritmo.Difficulty;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.JFrame;

public class Classifica extends javax.swing.JFrame {

    // --------------------------------------------------- ATTRIBUTI ---------------------------------------------------
    private javax.swing.JTextArea classifica;
    private javax.swing.JLabel player;
    private Point mouseClickPoint = null;
    private int punteggio = 0;
    private boolean isClassificaAttached;
    private static JCampoMinato parent;
    private Difficulty d;

    // --------------------------------------------------- METODI ---------------------------------------------------
    //costruttore
    public Classifica(JCampoMinato parent, String name, int x, int y, int height, Boolean isClassificaAttached, Difficulty d) {
        this.parent = parent;
        this.d = d;
        initComponents(name, x, y, height, isClassificaAttached);
    }

    //initcomponents
    private void initComponents(String name, int x, int y, int height, Boolean isClassificaAttached) {
        // ------------------------ FROM ------------------------ 
        getContentPane().setLayout(null);
        this.setUndecorated(true);
        //set dimensioni
        setBounds(x, y, 310, height);
        //altro
        setDefaultCloseOperation(Flag.DO_NOTHING_ON_CLOSE);
        this.setVisible(true);
        Color blue = new Color(180, 206, 180);
        this.getContentPane().setBackground(blue);
        this.isClassificaAttached = isClassificaAttached;

        // ------------------------ COMPONENTI ------------------------ 
        //panel
        classifica = new javax.swing.JTextArea();
        classifica.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51), 4));
        classifica.setBounds(5, 35, this.getBounds().width - 10, this.getBounds().height - 40);
        classifica.setBackground(new Color(180, 206, 180));
        classifica.setEditable(false);
        classifica.setFont(new java.awt.Font("Monospaced", 0, 12));
        getContentPane().add(classifica);

        //text field
        player = new javax.swing.JLabel(" " + name);
        player.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51), 2));
        player.setBounds(5, 5, this.getWidth() - 10, 25);
        player.setBackground(new Color(180, 206, 180));
        player.setFont(new java.awt.Font("Monospaced", 1, 16));
        getContentPane().add(player);

        //evento per resize
        addListenerToAllComponents(this, this);

        //aggiorno i componenti
        refresh();
    }

    //metodi miei
    private void refresh() {
        try {
            classifica.setText("");
            for (String s : PrelevaDati()) {

                //stiling
                String[] data = s.split(",");
                String spaces = "", spaces2 = "";
                for (int i = 0; i < 14 - data[0].length(); i++) {
                    spaces += " ";
                }
                for (int i = 0; i < 9 - data[1].length(); i++) {
                    spaces2 += " ";
                }

                classifica.setText(classifica.getText() + "  " + data[0] + spaces + " - " + data[1] + spaces2 + " [" + data[2] + "]\n");
            }
        } catch (Exception e) {
        }
    }

    public void addListenerToAllComponents(Container container, Classifica frame) {
        Component[] components = container.getComponents();
        for (Component component : components) {
            //aggiungo l'evento ai componenti
            component.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    if (evt.getClickCount() == 2) {
                        frame.setExtendedState(JFrame.ICONIFIED);
                    }
                }
            });
            component.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    mouseClickPoint = e.getPoint();
                }
            });
            component.addMouseMotionListener(new MouseMotionAdapter() {
                public void mouseDragged(MouseEvent e) {
                    Point currentCoords = e.getLocationOnScreen();
                    frame.setLocation(currentCoords.x - mouseClickPoint.x, currentCoords.y - mouseClickPoint.y);

                    if (frame.getX() + frame.getWidth() >= parent.getX() && frame.getX() <= parent.getX() + parent.getWidth()) {
                        isClassificaAttached = true;
                    } else {
                        isClassificaAttached = false;
                    }
                }
            });
            //aggiungo l'evento al gruppo di componenti per le label
            if (component instanceof Container) {
                addListenerToAllComponents((Container) component, frame);
            }
        }
    }

    /**
     * preleva i dati dalla classifica e li ordina
     *
     * @throws FileNotFoundException
     * @throws IOException 
    *
     */
    public ArrayList<String> PrelevaDati() throws FileNotFoundException, IOException {
        ArrayList<String> classifica = new ArrayList<>();

        //creo lettore e stringa per la riga
        BufferedReader br;

        br = new BufferedReader(new FileReader("classifica-" + d.name() + ".txt"));

        String riga;
        //salvo daqti riga per riga e le aggiunglo all' ArrayList
        while ((riga = br.readLine()) != null) {
            classifica.add(riga);
        }
        br.close();

        //ordino la classifica
        sort(classifica);

        //ritorno la classifica
        return classifica;

    }

    /**
     * scrive i dati della classifica nel file
     *
     * @throws FileNotFoundException
     * @throws IOException 
    *
     */
    public boolean ScriviDati(String newLine) throws FileNotFoundException, IOException {

        String[] classifica = this.classifica.getText().split("\n");

        //creo oggetto per scrivere 
        BufferedWriter br;

        br = new BufferedWriter(new FileWriter("classifica-" + d.name() + ".txt"));

        if (!classifica[0].equals("")) {
            //copio il resto che gia c'era
            for (int i = 0; i < classifica.length; i++) {
                br.write(format(classifica[i]));
                br.write("\n");
                br.flush();
            }
        }

        //aggiungo il risultato del nuovo giocatore
        br.write(newLine);
        br.close();

        return true;
    }

    public void calcolaPunteggio(Long elapsedTime, int caselle) {
        punteggio = (int) (caselle * 5 - elapsedTime.doubleValue());
    }

    /**
     * @return ritorna una stringa gia formattata che rappresenta lo stato del
     * giocatore corrente
    *
     */
    public String getStats() {
        return player.getText().substring(1) + "," + punteggio + "," + LocalDate.now().toString().replace("-", "/");  //al posto di 100 mettere il calcolo dei punti
    }

    public void setPos(int x, int y) {
        this.setLocation(x + 8, y);
    }

    public boolean getIsClassificaAttached() {
        return this.isClassificaAttached;
    }

    /**
     * trasforma dal formato scritto nella classifica a quello del file (forse è
     * stupido ed è meglio fare in append e dare un limite ai giocatori e
     * mostrare solo la top 200)
    *
     */
    private String format(String s) {
        String nome = s.split("-")[0];
        String dati = s.split("-")[1];

        while (nome.charAt(0) == ' ') {
            nome = nome.substring(1);
        }
        while (nome.charAt(nome.length() - 1) == ' ') {
            nome = nome.substring(0, nome.length() - 1);
        }

        while (dati.charAt(0) == ' ') {
            dati = dati.substring(1);
        }

        String punti = dati.split(" ")[0];
        String data = dati.split(" ")[dati.split(" ").length - 1].substring(1, dati.split(" ")[dati.split(" ").length - 1].length() - 1);

        return nome + "," + punti + "," + data;
    }

    /**
     * ordina un arraylist di stringhe che rappresentano i giocatori solo se
     * sono nel formato che ho fatto io
    *
     */
    private void sort(ArrayList<String> s) {
        int i, j;
        boolean swapped;
        for (i = 0; i < s.size() - 1; i++) {
            swapped = false;
            for (j = 0; j < s.size() - i - 1; j++) {
                if (Integer.parseInt(s.get(j).split(",")[1]) < Integer.parseInt(s.get(j + 1).split(",")[1])) {
                    String tmp = s.get(j);
                    s.set(j, s.get(j + 1));
                    s.set(j + 1, tmp);
                }
            }
        }
    }
}
